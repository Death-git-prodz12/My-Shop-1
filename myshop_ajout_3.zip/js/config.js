// Configuration centrale. API_BASE / STREAM_URL : laissez vide tant que le backend n'existe pas.
export const CONFIG = {
  firebase: {
    apiKey: "AIzaSyAOYmI2GaAs1XicBQC9gdFM1xDBybxiPtY",
    authDomain: "myshop-10.firebaseapp.com",
    projectId: "myshop-10",
    storageBucket: "myshop-10.firebasestorage.app",
    messagingSenderId: "474946515721",
    appId: "1:474946515721:web:eaf877545fdb807f2919d8"
  },
  API_BASE: "",     // ex. "https://api.exemple.com/v1" : GET /products, GET /products/:id/history
  STREAM_URL: "",   // ex. "https://api.exemple.com/v1/stream" (Server-Sent Events / webhook relayé)
  REFRESH_MS: 60000 // rafraîchissement si seul API_BASE est renseigné
};
