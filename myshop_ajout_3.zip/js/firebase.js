import { initializeApp } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-app.js";
import { getAuth, GoogleAuthProvider, signInWithPopup, signInWithRedirect, getRedirectResult, signOut, onAuthStateChanged }
  from "https://www.gstatic.com/firebasejs/10.8.0/firebase-auth.js";
import { CONFIG } from "./config.js";

const auth = getAuth(initializeApp(CONFIG.firebase));
const provider = new GoogleAuthProvider();
getRedirectResult(auth).catch(() => {});

// Résout avec l'utilisateur (ou null) dès que Firebase a restauré la session.
export const authReady = new Promise(res => { const off = onAuthStateChanged(auth, u => { off(); res(u); }); });
export const onUser = cb => onAuthStateChanged(auth, cb);
export const logOut = () => signOut(auth);
export const getApiAuthHeaders = async () => {
  if (auth.currentUser) return { Authorization: `Bearer ${await auth.currentUser.getIdToken()}` };
  return {};
};

export async function signIn() {
  try { return (await signInWithPopup(auth, provider)).user; }
  catch (e) {
    if (["auth/popup-blocked", "auth/operation-not-supported-in-this-environment"].includes(e.code)) {
      await signInWithRedirect(auth, provider); return null;
    }
    throw e;
  }
}

export const loginError = e => ({
  "auth/unauthorized-domain": "Ce domaine n'est pas autorisé : ajoutez-le dans Firebase, Authentication, Settings, Authorized domains.",
  "auth/popup-closed-by-user": "Connexion annulée.",
  "auth/cancelled-popup-request": "Connexion annulée.",
  "auth/network-request-failed": "Réseau indisponible."
}[e.code] || "Connexion impossible (" + (e.code || e.message) + ").");
