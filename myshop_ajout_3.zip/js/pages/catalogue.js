import { boot, card, ic, CAT, esc, yieldStats } from "../ui.js";
import { getProducts } from "../api.js";
import { summarizePremium, byMarginDesc } from "../pricing.js";

boot({ page: "catalogue", render: async ({ user, app }) => {
  const P = await getProducts();
  // Le segment « Undefined / Divers » apparaît dès qu'un produit n'a pas de catégorie reconnue (0 perte de données).
  const cats = ["all", ...new Set(P.map(p => p.category))];
  const platforms = [...new Set(P.map(p => p.platform || p.source || "Autre"))].sort((a, b) => a.localeCompare(b, "fr"));
  let cat = "all", q = "", platform = "all", sort = "featured", minMargin = 0;
  let premium = new URLSearchParams(location.search).get("premium") === "1";
  app.innerHTML = `<div class="sh"><div><h2 class="fd">Catalogue</h2><small>${P.length} produits · marges calculées (prix − coût) / prix, à titre estimatif</small></div><label class="glass sp">${ic("search", 18)}<input id="q" type="search" placeholder="Produit ou plateforme" autocomplete="off"></label></div>
    <div class="catalog-controls"><div class="rail" id="chips" aria-label="Catégories"></div>
    <div class="filter-row"><label class="filter-control"><span>Plateforme</span><select id="platform"><option value="all">Toutes les plateformes</option>${platforms.map(x => `<option value="${esc(x)}">${esc(x)}</option>`).join("")}</select></label>
    <label class="filter-control"><span>Marge minimale</span><select id="margin"><option value="0">Toutes</option><option value="20">≥ 20 %</option><option value="30">≥ 30 %</option><option value="40">≥ 40 %</option></select></label>
    <label class="filter-control"><span>Trier par</span><select id="sort"><option value="featured">Sélection</option><option value="price-asc">Prix croissant</option><option value="price-desc">Prix décroissant</option><option value="profit">Marge estimée</option></select></label>
    <label class="premium-filter"><input id="premium" type="checkbox" ${premium ? "checked" : ""}><span>${ic("crown", 14)} Premium · High-Yield</span></label></div></div>
    <p class="catalog-disclaimer">Les prix et coûts de démonstration doivent être confirmés auprès des vendeurs avant toute décision commerciale. La marge brute exclut livraison, taxes, retours et frais de plateforme.</p>
    <div id="hy"></div><div class="gr" id="g"></div>`;
  const $ = id => document.getElementById(id);
  const setPremium = on => { premium = on; $("premium").checked = on; draw(); };

  const draw = () => {
    $("chips").innerHTML = cats.map(c => `<button class="seg ${c === cat ? "on" : ""}" data-cat="${esc(c)}">${c === "all" ? "Tout" : esc(CAT[c] || CAT.divers)}</button>`).join("");
    const L = P.filter(p => (cat === "all" || p.category === cat)
      && (platform === "all" || (p.platform || p.source) === platform)
      && (!premium || p.isPremium)
      && (minMargin === 0 || (p.profitMargin ?? -Infinity) >= minMargin)
      && (`${p.title} ${p.platform} ${CAT[p.category] || CAT.divers} ${p.rawCategory}`).toLocaleLowerCase("fr").includes(q));
    if (sort === "price-asc") L.sort((a, b) => (a.price ?? Infinity) - (b.price ?? Infinity));
    if (sort === "price-desc") L.sort((a, b) => (b.price ?? -Infinity) - (a.price ?? -Infinity));
    if (sort === "profit") L.sort(byMarginDesc);

    // Section dédiée Premium / High-Yield : vitrine quand aucun filtre n'est actif, synthèse quand le filtre Premium est actif.
    const showcase = P.filter(p => p.isPremium).sort(byMarginDesc);
    const untouched = cat === "all" && !q && platform === "all" && !minMargin && !premium;
    if (showcase.length && untouched) {
      $("hy").innerHTML = `<section class="premium-section" aria-labelledby="hy-title"><div class="sh"><div><span class="premium-kicker">${ic("crown", 14)} High-Yield</span><h2 class="fd" id="hy-title">Premium · fort potentiel</h2><small>Produits à forte marge, panier élevé ou excellentes performances.</small></div><button class="bt g" id="onlyPremium" type="button">${ic("crown", 16)}Afficher uniquement ce segment</button></div>${yieldStats(summarizePremium(P))}<div class="gr">${showcase.slice(0, 4).map(p => card(p, user)).join("")}</div></section>`;
      $("onlyPremium").onclick = () => setPremium(true);
    } else if (premium) {
      $("hy").innerHTML = `<section class="premium-section" aria-label="Synthèse Premium"><div class="sh"><div><span class="premium-kicker">${ic("crown", 14)} High-Yield</span><h2 class="fd">Segment Premium</h2></div><button class="bt g" id="allProducts" type="button">Voir tout le catalogue</button></div>${yieldStats(summarizePremium(L))}</section>`;
      $("allProducts").onclick = () => setPremium(false);
    } else $("hy").innerHTML = "";

    $("g").innerHTML = L.map(p => card(p, user)).join("") || '<div class="glass empty"><h3>Aucun résultat</h3><p>Essaie d’ajuster les filtres.</p></div>';
  };
  $("chips").addEventListener("click", e => { const b = e.target.closest("[data-cat]"); if (b) { cat = b.dataset.cat; draw(); } });
  $("q").addEventListener("input", e => { q = e.target.value.trim().toLocaleLowerCase("fr"); draw(); });
  $("platform").addEventListener("change", e => { platform = e.target.value; draw(); });
  $("margin").addEventListener("change", e => { minMargin = Number(e.target.value); draw(); });
  $("sort").addEventListener("change", e => { sort = e.target.value; draw(); });
  $("premium").addEventListener("change", e => { premium = e.target.checked; draw(); });
  draw();
} });
