import { boot, card, ic, yieldStats } from "../ui.js";
import { getProducts, watchLive } from "../api.js";
import { CONFIG } from "../config.js";
import { summarizePremium, byMarginDesc } from "../pricing.js";

boot({ page: "index", render: async ({ user, app }) => {
  const draw = P => {
    const premium = P.filter(p => p.isPremium).sort(byMarginDesc);
    const stats = [["grid", "Produits", P.length], ["chart", "Plateformes", new Set(P.map(p => p.platform)).size], ["crown", "Premium · High-Yield", premium.length]];
    app.innerHTML = `<section class="hero"><div class="live ${CONFIG.API_BASE ? "on" : ""}">${ic("info", 14)}${CONFIG.API_BASE ? "Source API configurée" : "Données de référence · flux en direct non connecté"}</div>
<h1 class="fd">Suivez les produits viraux du monde entier.</h1>
<p class="sub">MyShop rassemble des produits tendance de Shopify, Temu, AliExpress, Shein, Amazon, Alibaba, TikTok Shop et CJ Dropshipping, avec leur marge estimée et un lien vers leur plateforme d’origine.</p>
<div class="hs">${stats.map(([i, label, value]) => `<div class="glass sx"><span class="chip">${ic(i, 16)}</span><span><small>${label}</small><b>${value}</b></span></div>`).join("")}</div></section>
${premium.length ? `<section class="premium-section" aria-labelledby="hy-title"><div class="sh"><div><span class="premium-kicker">${ic("crown", 14)} sélection MyShop</span><h2 class="fd" id="hy-title">Premium · High-Yield</h2><small>Forte marge, panier élevé ou meilleures performances : les produits à regarder en premier.</small></div><a class="text-link" href="catalogue.html?premium=1">Voir tout le segment →</a></div>
${yieldStats(summarizePremium(P))}
<div class="gr">${premium.slice(0, 4).map(p => card(p, user)).join("")}</div></section>` : ""}
<div class="sh"><h2 class="fd">Explorer les tendances</h2><a class="text-link" href="catalogue.html">Filtres avancés →</a></div><div class="gr" id="g">${P.map(p => card(p, user)).join("")}</div>`;
  };
  draw(await getProducts());
  watchLive(async () => draw(await getProducts(true)));
} });
