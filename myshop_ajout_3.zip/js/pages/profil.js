import { boot, esc, ic, safeUrl } from "../ui.js";
import { logOut } from "../firebase.js";
import { watchList } from "../store.js";

const fmt = s => s ? new Date(s).toLocaleDateString("fr-FR", { day: "numeric", month: "long", year: "numeric" }) : "—";

boot({ page: "profil", guard: true, render: async ({ user, app }) => {
  const name = user.displayName || "Utilisateur", google = user.providerData.some(p => p.providerId === "google.com");
  app.innerHTML = `<div class="sh"><h2 class="fd">Profil</h2></div>
<div class="pg"><section class="glass pad prof"><div class="avatar">${user.photoURL ? `<img src="${esc(safeUrl(user.photoURL))}" alt="" referrerpolicy="no-referrer">` : esc(name.slice(0, 2).toUpperCase())}</div>
<h3 class="fd" style="font-size:30px">${esc(name)}</h3><p class="mu">${esc(user.email || "")}</p>
<div style="width:100%;margin-top:14px"><div class="ln"><span>Connexion</span><span>${google ? "Compte Google" : "Autre"}</span></div><div class="ln"><span>Inscrit le</span><span>${fmt(user.metadata.creationTime)}</span></div><div class="ln"><span>Dernière connexion</span><span>${fmt(user.metadata.lastSignInTime)}</span></div></div></section>
<aside class="glass pad"><h3 class="fd" style="font-size:24px;margin-bottom:10px">Mon espace</h3><div class="ln"><span>Produits surveillés</span><span>${watchList(user).length}</span></div>
<a class="bt g w" style="margin:14px 0 8px" href="surveillance.html">${ic("mark", 16)}Panier de surveillance</a>
<button class="bt w" id="out">${ic("out", 16)}Se déconnecter</button></aside></div>`;
  document.getElementById("out").onclick = async () => { await logOut(); location.href = "index.html"; };
} });
