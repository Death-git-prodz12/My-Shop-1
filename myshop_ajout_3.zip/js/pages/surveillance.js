import { boot, card, empty } from "../ui.js";
import { getProducts } from "../api.js";
import { watchList } from "../store.js";

boot({ page: "surveillance", guard: true, render: async ({ user, app }) => {
  const P = await getProducts();
  const draw = () => {
    const L = watchList(user).map(id => P.find(p => p.id === id)).filter(Boolean);
    app.innerHTML = `<div class="sh"><h2 class="fd">Panier de surveillance</h2><small>${L.length} produit${L.length > 1 ? "s" : ""}</small></div>` +
      (L.length ? `<div class="gr">${L.map(p => card(p, user)).join("")}</div>` : empty("mark", "Aucun produit surveillé", "Appuyez sur l'icône marque-page d'un produit pour l'ajouter ici.", "catalogue.html", "Parcourir le catalogue"));
  };
  draw();
  document.addEventListener("watch:changed", draw);
} });
