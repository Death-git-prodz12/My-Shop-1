// Per-user local state. Replace this adapter with Firestore without changing pages.
const key = user => `myshop:watch:${encodeURIComponent(user.uid)}`;
const parse = value => {
  try {
    const result = JSON.parse(value || "[]");
    return Array.isArray(result) ? [...new Set(result.filter(id => typeof id === "string"))] : [];
  } catch { return []; }
};
const read = user => {
  if (!user?.uid) return [];
  try { return parse(localStorage.getItem(key(user))); } catch { return []; }
};

export const watchList = user => read(user);
export const isWatched = (user, id) => !!user?.uid && read(user).includes(String(id));

export function toggleWatch(user, id) {
  if (!user?.uid) return false;
  const list = read(user), productId = String(id), index = list.indexOf(productId);
  const added = index < 0;
  if (added) list.push(productId); else list.splice(index, 1);
  try { localStorage.setItem(key(user), JSON.stringify(list)); } catch (error) {
    console.warn("[MyShop] Impossible d’enregistrer la surveillance sur cet appareil.", error);
  }
  return added;
}

// Keep open tabs in sync when the same account changes its saved list elsewhere.
if (typeof window !== "undefined") window.addEventListener("storage", event => {
  if (event.key?.startsWith("myshop:watch:")) document.dispatchEvent(new CustomEvent("watch:changed", { detail: { external: true } }));
});
