import { authReady, onUser } from "./firebase.js";
import { isWatched, toggleWatch } from "./store.js";
import { CAT, FALLBACK_CATEGORY } from "./categories.js";
import { formatPercent } from "./pricing.js";

export const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
export const safeUrl = u => /^https:\/\//i.test(u || "") ? u : "#";
export const ic = (n, s = 18) => `<svg class="i" width="${s}" height="${s}" aria-hidden="true"><use href="#i-${n}"/></svg>`;
export { CAT, FALLBACK_CATEGORY };
export const catLabel = p => CAT[p?.category] || CAT[FALLBACK_CATEGORY];
export const curPage = () => (location.pathname.split("/").pop() || "index.html") + location.search;
export const price = p => {
  const n = p.price ?? p.priceRef;
  return n != null && Number.isFinite(Number(n))
    ? new Intl.NumberFormat("fr-FR", { style: "currency", currency: p.currency || "USD" }).format(Number(n))
    : "Prix sur la plateforme";
};
export const extLabel = p => p.linkType === "product" ? "Voir la fiche sur " + p.source : "Rechercher sur " + p.source;


const money2 = (n, currency) => new Intl.NumberFormat("fr-FR", { style: "currency", currency: currency || "USD" }).format(Number(n));
const MARGIN_LABEL = { high: "Marge élevée", mid: "Marge correcte", low: "Marge faible", loss: "Vente à perte", unknown: "Marge à confirmer" };

/** Pastille de marge : toujours visible. Sans coût connu, elle l'indique au lieu d'inventer un chiffre. */
export const marginChip = (p, extra = "") => {
  const tier = p.marginTier || "unknown";
  const known = Number.isFinite(p.profitMargin);
  const sim = known && (p.costMode === "simulation" || p.dataMode === "demo") ? " · simulation" : "";
  const label = known ? `Marge ${formatPercent(p.profitMargin)}` : MARGIN_LABEL.unknown;
  const tip = known ? `${MARGIN_LABEL[tier]} : (prix − coût) / prix × 100${sim}` : "Renseignez le coût fournisseur pour calculer la marge";
  return `<span class="margin-chip tier-${tier} ${extra}" title="${esc(tip)}">${ic("trend", 12)}${esc(label)}</span>`;
};

export const premiumBadge = (p, cls = "", full = false) => p.isPremium
  ? `<span class="premium-badge ${cls}" title="${esc(p.premiumReasons?.length ? p.premiumReasons.join(" · ") : "Sélection Premium / High-Yield")}">${ic("crown", 11)}${full ? "Premium · High-Yield" : "Premium"}</span>` : "";

/** Bandeau de synthèse du segment Premium (accueil + catalogue). */
export const yieldStats = s => `<div class="yield-stats" role="list">
  <div class="glass ys" role="listitem"><small>Produits High-Yield</small><b>${s.count}</b></div>
  <div class="glass ys" role="listitem"><small>Marge moyenne</small><b>${s.averageMargin != null ? formatPercent(s.averageMargin) : "—"}</b></div>
  <div class="glass ys" role="listitem"><small>Meilleure marge</small><b>${s.bestMargin != null ? formatPercent(s.bestMargin) : "—"}</b></div>
  <div class="glass ys" role="listitem"><small>Plateformes</small><b>${s.platforms}</b></div></div>`;

const S = (id, b) => `<symbol id="i-${id}" viewBox="0 0 24 24">${b}</symbol>`;
const SPRITE = `<svg width="0" height="0" style="position:absolute" aria-hidden="true"><defs>${[
  S("home", '<path d="M3 10.5 12 3l9 7.5V20a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z"/>'),
  S("grid", '<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/>'),
  S("mark", '<path d="M6 3h12v18l-6-4-6 4z"/>'),
  S("user", '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>'),
  S("chart", '<path d="M3 3v18h18"/><path d="m7 15 4-5 3 3 5-6"/>'),
  S("ext", '<path d="M7 17 17 7M8 7h9v9"/>'),
  S("lock", '<rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>'),
  S("info", '<circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8v.01"/>'),
  S("back", '<path d="M19 12H5M12 19l-7-7 7-7"/>'),
  S("out", '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9"/>'),
  S("search", '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>'),
  S("check", '<path d="m5 12 5 5L20 7"/>'),
  S("crown", '<path d="m3 8 4.5 4L12 5l4.5 7L21 8l-2 11H5z"/>'),
  S("trend", '<path d="m3 17 6-6 4 4 8-8"/><path d="M15 7h6v6"/>')
].join("")}</defs></svg>`;
const BAG = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 8h14l-1 12H6z"/><path d="M9 8V7a3 3 0 0 1 6 0v1"/></svg>';
const NAV = [["index", "home", "Accueil"], ["catalogue", "grid", "Catalogue"], ["surveillance", "mark", "Surveillance"]];

const hue = id => [...id].reduce((a, c) => a + c.charCodeAt(0), 0) % 360;
const ini = n => n.split(/\s+/).map(w => w[0]).join("").slice(0, 2).toUpperCase();

export function card(p, user) {
  const title = p.title || p.name, platform = p.platform || p.source || "Autre";
  const w = isWatched(user, p.id), href = "produit.html?id=" + encodeURIComponent(p.id);
  const image = p.images?.[0] || p.image;
  const img = image ? `<img src="${esc(safeUrl(image))}" alt="${esc(title)}" loading="lazy" referrerpolicy="no-referrer" onerror="this.remove()">` : "";
  const external = p.sourceUrl ? `<a class="ib sm" href="${esc(safeUrl(p.sourceUrl))}" target="_blank" rel="noopener noreferrer" data-ext data-tip="${esc(extLabel(p))}" aria-label="${esc(extLabel(p))}">${ic("ext", 16)}</a>` : `<span class="ib sm disabled" title="Lien externe indisponible" aria-label="Lien externe indisponible">${ic("ext", 16)}</span>`;
  const margin = p.profitAmount != null ? `<small class="profit-tag">Bénéfice brut ≈ ${esc(money2(p.profitAmount, p.currency))} / unité</small>` : "";
  return `<article class="glass card ${p.isPremium ? "is-premium" : ""}"><a class="tile" href="${href}" data-go style="--h:${hue(p.id)}" aria-label="Découvrir ${esc(title)}">${img}<b>${esc(ini(title))}</b><span class="tg">${esc(platform)}</span>${marginChip(p, "on-tile")}${premiumBadge(p)}</a>
<div><h3 class="fd"><a href="${href}" data-go>${esc(title)}</a></h3><small>${esc(catLabel(p))}</small></div>
<div class="row"><div><div class="px">${esc(price(p))}</div><small>${p.linkType === "product" ? "Fiche directe" : "Lien de recherche"}${p.costPrice != null ? ` · Coût ${new Intl.NumberFormat("fr-FR", { style: "currency", currency: p.currency || "USD" }).format(p.costPrice)}` : ""}</small>${margin}</div>
<div class="acts"><a class="ib sm" href="${href}" data-go data-tip="Analyser" aria-label="Analyser">${ic("chart", 16)}</a>
${external}
<button class="ib sm ${w ? "on" : ""}" data-watch="${esc(p.id)}" data-tip="Surveiller" aria-label="Surveiller" aria-pressed="${w}">${ic("mark", 16)}</button></div></div></article>`;
}

export const empty = (i, t, x, href, l) => `<div class="glass empty">${ic(i, 32)}<div class="fd">${esc(t)}</div><p>${esc(x)}</p>${href ? `<a class="bt" href="${href}">${esc(l)}</a>` : ""}</div>`;

export function lineChart(v) {
  const a = Math.min(...v), b = Math.max(...v), r = b - a || 1;
  const p = v.map((x, i) => `${(i / (v.length - 1) * 200).toFixed(1)},${(29 - (x - a) / r * 26).toFixed(1)}`).join(" ");
  return `<svg viewBox="0 0 200 32" preserveAspectRatio="none" style="width:100%;height:280px;display:block" role="img" aria-label="Historique des prix"><polyline points="${p}" fill="none" stroke="#7DD3FC" stroke-width="1.8" stroke-linejoin="round" vector-effect="non-scaling-stroke"/></svg>`;
}

let USER = null;
export const toLogin = (next, reason) => { location.href = "connexion.html?next=" + encodeURIComponent(next) + "&reason=" + reason; };

function layout(active) {
  const nav = items => items.map(([p, i, l]) => `<a class="ib ${p === active ? "on" : ""}" href="${p}.html" data-tip="${l}" aria-label="${l}">${ic(i, 20)}</a>`).join("");
  document.body.dataset.theme = localStorage.getItem("myshop:theme") || "light";
  document.body.insertAdjacentHTML("afterbegin", SPRITE +
    `<header class="hd glass"><span class="header-spacer" aria-hidden="true"></span><a class="lg" href="index.html" aria-label="MyShop, accueil"><img class="myshop-logo" src="assets/MyShop-transparent.png" alt="MyShop"></a><div class="ra"><button class="theme-toggle" id="theme" type="button" aria-label="Activer le thème sombre">◐</button><a class="av" id="acc" href="connexion.html" data-tip="Connexion" aria-label="Connexion">${ic("user", 18)}</a></div></header><main id="app"></main><nav class="dk" aria-label="Navigation principale">${nav([...NAV, ["profil", "user", "Profil"]])}</nav>`);
  document.getElementById("theme").addEventListener("click", () => {
    const next = document.body.dataset.theme === "dark" ? "light" : "dark";
    document.body.dataset.theme = next;
    localStorage.setItem("myshop:theme", next);
    document.getElementById("theme").setAttribute("aria-label", next === "dark" ? "Activer le thème clair" : "Activer le thème sombre");
  });
}

function setAccount(u) {
  const a = document.getElementById("acc");
  if (!u) return;
  a.href = "profil.html"; a.dataset.tip = "Profil"; a.setAttribute("aria-label", "Profil");
  a.innerHTML = u.photoURL ? `<img src="${esc(safeUrl(u.photoURL))}" alt="" referrerpolicy="no-referrer">` : esc((u.displayName || u.email || "U").slice(0, 2).toUpperCase());
}

// Auth Guard : un visiteur non connecté qui clique sur un produit ou une action est envoyé vers connexion.html.
document.addEventListener("click", e => {
  const a = e.target.closest("[data-go],[data-ext],[data-watch]");
  if (!a) return;
  if (!USER) {
    if (a.hasAttribute("data-ext")) return;
    e.preventDefault();
    const isGo = a.hasAttribute("data-go");
    toLogin(isGo ? a.getAttribute("href") : curPage(), isGo ? "product" : "action");
    return;
  }
  if (a.dataset.watch !== undefined) {
    const on = toggleWatch(USER, a.dataset.watch);
    a.classList.toggle("on", on); a.setAttribute("aria-pressed", on);
    document.dispatchEvent(new CustomEvent("watch:changed", { detail: { id: a.dataset.watch, on } }));
  }
});

export async function boot({ page, guard = false, render }) {
  layout(page);
  USER = await authReady;
  setAccount(USER);
  if (guard && !USER) { location.replace("connexion.html?next=" + encodeURIComponent(curPage()) + "&reason=guard"); return; }
  onUser(u => { if ((u?.uid || null) !== (USER?.uid || null)) location.reload(); });
  await render({ user: USER, app: document.getElementById("app") });
}
